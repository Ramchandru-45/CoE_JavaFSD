import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  username: string = '';
   password: string = '';
   constructor(private router:Router){
   }

   login(){
  
     if(this.username=="elonmusk" && this.password
     =="admin"){
   
       localStorage.setItem("username",this.username)
       window.location.reload()
       this.router.navigate([''])
   }
   else if(this.username=="elonmusk" && this.password!="admin"){
     alert("Invalid Password")
   }  
   else {
    localStorage.setItem("username",this.username)
    window.location.reload()
    this.router.navigate([''])
   }
 }
}
