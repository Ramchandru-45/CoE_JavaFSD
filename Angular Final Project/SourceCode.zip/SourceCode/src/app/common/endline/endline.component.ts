import { Component } from '@angular/core';

@Component({
  selector: 'app-endline',
  templateUrl: './endline.component.html',
  styleUrl: './endline.component.css'
})
export class EndlineComponent {

}
