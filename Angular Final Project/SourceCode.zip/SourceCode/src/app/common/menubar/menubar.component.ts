import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrl: './menubar.component.css'
})
export class MenubarComponent {

  isadmin:boolean=false;
  status:boolean=false;
   loginmenu:string="Login"
      constructor(private router:Router){
        let username = localStorage.getItem("username")
         if(username=="elonmusk"){
            this.isadmin=true;
           this.status=true;
           this.loginmenu=username+", Logout"
         }
         else if(username){
            this.status=true;
           this.loginmenu=username+", Logout"
         }
        
      }
 
      loginhandler(){
         if(this.status){
           localStorage.removeItem("username")
           window.location.reload()
         }
         else{
           this.router.navigate(['/loginpage'])
           
      }
 }
}
