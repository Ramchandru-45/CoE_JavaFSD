import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) { }

  getResult():Observable<any>{
    return this.http.get('http://localhost:4500/forum');
  }

  getGames():Observable<any>{
    return this.http.get('http://localhost:4500/game');
  }
  getGame(id:string):Observable<any>{
    return this.http.get('http://localhost:4500/game/'+id);
  }

  getRequests():Observable<any>{
    return this.http.get('http://localhost:4500/requests');
  }

  addRequest(data:any):Observable<any>{
    return this.http.post('http://localhost:4500/requests',data);
  }

  addMessage(data:any):Observable<any>{
    return this.http.post('http://localhost:4500/forum',data);
  }
}
