export interface Request{
    id:string,
    name:string,
    email:string,
    serviceType:string,
    message:string
}