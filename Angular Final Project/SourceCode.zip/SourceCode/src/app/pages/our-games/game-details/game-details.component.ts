import { Component, Input } from '@angular/core';
import { Game } from '../../../model/game';
import { ApiService } from '../../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-game-details',
  templateUrl: './game-details.component.html',
  styleUrl: './game-details.component.css'
})
export class GameDetailsComponent {
  id:any = '';
   title:string = '';
   description:string[] = [];
   constructor(private route: ActivatedRoute,private router:Router
     ,private api:ApiService
   ) {
     this.id = this.route.snapshot.paramMap.get('id');
     const navigation = this.router.getCurrentNavigation();
     console.log(navigation)
     if (navigation?.extras.state) {
       this.title = navigation.extras.state['title'];
       console.log('Title:', this.title);
     }     
   }

  ngOnInit() {
 
    this.api.getGame(this.id).subscribe({
      next	: (result:any) => {
       console.log(result)
         this.description = result[0].description
      },
      error: (error:any) => console.log(error)
    });
      
 
   }
}
