import { Component, Input } from '@angular/core';
import { Game } from '../../../model/game';
import { Router } from '@angular/router';

@Component({
  selector: 'app-game-item',
  templateUrl: './game-item.component.html',
  styleUrl: './game-item.component.css'
})
export class GameItemComponent {
  @Input() game: Game= {
    id: '',
    title: '',
    description: '',
    image: ''
  };

  constructor(private router:Router){}

  viewGame(id:string) {
    this.router.navigate(['/viewgame', id], { state: { title: this.game.title } });
  }
}
