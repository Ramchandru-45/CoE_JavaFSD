import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Game } from '../../model/game';

@Component({
  selector: 'app-our-games',
  templateUrl: './our-games.component.html',
  styleUrl: './our-games.component.css'
})
export class OurGamesComponent {

  gamelist:Game[] = [];
    constructor(private as: ApiService) { }

    ngOnInit(): void {
      this.as.getGames().subscribe({
        next:(data: any) => {
        this.gamelist = data;
        },
        error:(err: any) => {
          console.log(err);
        }
    });
    }
}
