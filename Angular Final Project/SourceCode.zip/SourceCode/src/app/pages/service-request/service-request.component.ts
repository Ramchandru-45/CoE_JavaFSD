import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Request } from '../../model/request';
@Component({
  selector: 'app-service-request',
  templateUrl: './service-request.component.html',
  styleUrl: './service-request.component.css'
})
export class ServiceRequestComponent {
  requestlist:Request[]=[];

  serviceTypes: string[] = [
    'All',
    'Game Support',
    'Game Bug Fixing',
    'Game Malfuction',
    'Feature Request',
    'ECommerce & Websites issues',
    'Refund Request',
    'Others'
  ];

  selected:string='All';
  constructor(private as: ApiService) { }
    
  ngOnInit():void{
    this.as.getRequests().subscribe({
      next:(response:Request[]) => {
        this.requestlist = response;
      },
      error:(err: any) => {
        console.log(err);
      }
    });
  }

  viewRequest(data:Request){
    console.log(data);
  }
}
