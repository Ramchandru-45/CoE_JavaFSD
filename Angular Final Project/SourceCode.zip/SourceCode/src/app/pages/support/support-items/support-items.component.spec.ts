import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportItemsComponent } from './support-items.component';

describe('SupportItemsComponent', () => {
  let component: SupportItemsComponent;
  let fixture: ComponentFixture<SupportItemsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SupportItemsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SupportItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
