import { Component } from '@angular/core';

@Component({
  selector: 'app-support-items',
  templateUrl: './support-items.component.html',
  styleUrl: './support-items.component.css'
})
export class SupportItemsComponent {

}
