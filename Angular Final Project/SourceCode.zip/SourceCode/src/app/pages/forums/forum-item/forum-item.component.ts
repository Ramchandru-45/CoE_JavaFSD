import { Component, Input } from '@angular/core';
import { Message } from '../../../model/message';

@Component({
  selector: 'app-forum-item',
  templateUrl: './forum-item.component.html',
  styleUrl: './forum-item.component.css'
})
export class ForumItemComponent {
  @Input() message: Message={
    id:'',
    user:'',
    message:''
  }
}
