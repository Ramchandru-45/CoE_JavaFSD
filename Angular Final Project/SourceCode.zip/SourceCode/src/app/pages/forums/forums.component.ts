import { Component } from '@angular/core';
import { Message } from '../../model/message';
import { ApiService } from '../../services/api.service';
@Component({
  selector: 'app-forums',
  templateUrl: './forums.component.html',
  styleUrl: './forums.component.css'
})
export class ForumsComponent {
  user=localStorage.getItem('username');
  chat='';
  resultlist: Message[]=[]

  constructor(private as:ApiService) { }

  ngOnInit(): void {
    this.as.getResult().subscribe({
      next:(result:Message[])=>{this.resultlist=result},
      error:(error)=>{console.log(error)}
    })
  }

  sendMessage(){
    if(this.user){
      this.as.addMessage({
        id:this.resultlist[this.resultlist.length-1].id+1,
        user:this.user,
        message:this.chat
      }).subscribe({
        next:(response)=>{
          console.log(response)
          this.chat=''
          this.ngOnInit()
        }
      })
    }
    else{
      alert("Please login to send message")
      this.chat=''
    }
  }
}
