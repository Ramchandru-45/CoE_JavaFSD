import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenubarComponent } from './common/menubar/menubar.component';
import { HomeComponent } from './pages/home/home.component';
import { AboutUsComponent } from './pages/home/about-us/about-us.component';
import { ForumsComponent } from './pages/forums/forums.component';
import { SupportComponent } from './pages/support/support.component';
import { EndlineComponent } from './common/endline/endline.component';
import { OurGamesComponent } from './pages/our-games/our-games.component';
import { ForumItemComponent } from './pages/forums/forum-item/forum-item.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { GameItemComponent } from './pages/our-games/game-item/game-item.component';
import { GameDetailsComponent } from './pages/our-games/game-details/game-details.component';
import { EnquiryFormComponent } from './pages/home/enquiry-form/enquiry-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './common/login/login.component';
import { ServiceRequestComponent } from './pages/service-request/service-request.component';
import { SupportItemsComponent } from './pages/support/support-items/support-items.component';
import { FilterservicePipe } from './pipes/filterservice.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MenubarComponent,
    HomeComponent,
    AboutUsComponent,
    ForumsComponent,
    SupportComponent,
    EndlineComponent,
    OurGamesComponent,
    ForumItemComponent,
    GameItemComponent,
    GameDetailsComponent,
    EnquiryFormComponent,
    LoginComponent,
    ServiceRequestComponent,
    SupportItemsComponent,
    FilterservicePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
