import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { ForumsComponent } from './pages/forums/forums.component';
import { SupportComponent } from './pages/support/support.component';
import { OurGamesComponent } from './pages/our-games/our-games.component';
import { LoginComponent } from './common/login/login.component';
import { ServiceRequestComponent } from './pages/service-request/service-request.component';
import { requestsGuard } from './gaurds/requests.guard';
import { GameDetailsComponent } from './pages/our-games/game-details/game-details.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'games', component: OurGamesComponent },
  { path: 'forums', component: ForumsComponent },
  { path: 'support', component: SupportComponent },
  {path: 'loginpage', component: LoginComponent},
  {path: 'viewgame',component:GameDetailsComponent},
  {path: 'requests', component: ServiceRequestComponent,canActivate:[requestsGuard]},
  { path: '', redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
