import { Pipe, PipeTransform } from '@angular/core';
import { Request } from '../model/request';
@Pipe({
  name: 'filterservice'
})
export class FilterservicePipe implements PipeTransform {

  transform(requestlist: Request[], serviceType:string): Request[] {
    if(serviceType === 'All') 
      return requestlist;
    
    return requestlist.filter(request => request.serviceType === serviceType);
  }

}
