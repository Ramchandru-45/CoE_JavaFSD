import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { requestsGuard } from './requests.guard';

describe('requestsGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => requestsGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
