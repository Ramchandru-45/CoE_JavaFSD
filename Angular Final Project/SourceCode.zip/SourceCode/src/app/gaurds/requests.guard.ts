import { CanActivateFn } from '@angular/router';

export const requestsGuard: CanActivateFn = (route, state) => {
  const username = localStorage.getItem('username');
  return username=='elonmusk' ? true : false;
};
