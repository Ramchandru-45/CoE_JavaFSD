import 'package:flutter/material.dart';
import 'package:mobileapp/pages/localization.dart';
import 'pages/language.dart';
import 'pages/credits.dart';
import 'pages/profile.dart';
import 'pages/repo.dart';
class MyHomePage extends StatefulWidget {
  final Function(Locale) onLocaleChange;

  MyHomePage({required this.onLocaleChange});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("GIT ${AppLocalizations.of(context).translate('title')}"),
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=> Language()));
              }, 
              child: Text(AppLocalizations.of(context).translate("language"))),
              SizedBox(width: 10,)
              ],
            ),
            
            Text('GIT',
              style: TextStyle(fontSize: 70,fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 30,),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfilePage()),
                );
              },
              child: Text(AppLocalizations.of(context).translate("profile")),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RepositoryPage()),
                );
              }, child: Text(AppLocalizations.of(context).translate("repository"))),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CreditsPage()),
                );
              },
              child: Text(AppLocalizations.of(context).translate("About")),
            )
            
          ],
        )
        
      ),
    );
  }
}
