class Repositories {
  String title;
  String access;
  String language;

  Repositories.fromJson(Map json)
      : title = json['title'],
        access = json['access'],
        language = json['language'];

  Map toJson() {
    return {
      'title': title,
      'access': access,
      'language': language,
    };
  }
}