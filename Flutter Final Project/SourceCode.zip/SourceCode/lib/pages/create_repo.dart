
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CreateRepoPage extends StatefulWidget {
  
  @override
  _CreateRepoPageState createState() => _CreateRepoPageState();
}

class _CreateRepoPageState extends State<CreateRepoPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _accessController = TextEditingController();
  final TextEditingController _languageController = TextEditingController();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void _addRepository() async {
    final String name = _nameController.text.trim();
    final String access = _accessController.text.trim();
    final String language = _languageController.text.trim();

    if (name.isNotEmpty && access.isNotEmpty && language.isNotEmpty) {
      try {
        await _firestore.collection('repositories').add({
          'name': name,
          'access': access,
          'language': language,
          'createdAt': FieldValue.serverTimestamp(),
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Repository added successfully!')),
        );
        _nameController.clear();
        _accessController.clear();
        _languageController.clear();
        Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => widget ),
                ); 
       
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to add repository: $e')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please fill in all fields')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Repository'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Repository Name'),
            ),
            TextField(
              controller: _accessController,
              decoration: InputDecoration(labelText: 'Access (e.g., public/private)'),
            ),
            TextField(
              controller: _languageController,
              decoration: InputDecoration(labelText: 'Language'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed:
                 _addRepository,            
              child: Text('Add Repository'),
            ),
          ],
        ),
      ),
    );
  }
}