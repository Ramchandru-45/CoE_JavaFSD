import 'package:flutter/material.dart';
import '../main.dart';
import 'localization.dart';

class Language extends StatelessWidget {
  const Language({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).translate('language select')),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: () {
                _changeLanguage(context, const Locale('en'));
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => this ),
                );
              },
              child: const Text('English'),
            ),
            ElevatedButton(
              onPressed: () {
                _changeLanguage(context, const Locale('es'));
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => this ),
                );
              },
              child: const Text('Español'),
            ),
            ElevatedButton(
              onPressed: () {
                _changeLanguage(context, const Locale('fr'));
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => this ),
                );
              },
              child: const Text('Français'),
            ),
          ],
        ),
      ),
    );
  }

  void _changeLanguage(BuildContext context, Locale locale) {
    MyApp.setLocale(context, locale);
  }
}

