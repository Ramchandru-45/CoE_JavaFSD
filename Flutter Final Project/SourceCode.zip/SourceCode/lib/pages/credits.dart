import 'package:flutter/material.dart';

import 'localization.dart';

class CreditsPage extends StatelessWidget {
  const CreditsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).translate("about")),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              AppLocalizations.of(context).translate("license"),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Default Licence: MIT License'),
            Text('License URL: https://opensource.org/licenses/MIT'),
            Text('Licence Type: Open Source'),
            Text('Licence Description: The MIT License is a permissive free software license originating at the Massachusetts Institute of Technology (MIT) in the late 1980s.'),
            SizedBox(height: 20),
            Text(
              AppLocalizations.of(context).translate("soft"),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('App Version: 1.0'),
            Text('Build Number: UPH4543J4K9'),
            Text('Software Version: 0.1.2'),
            Text('Kernal Version: 7827548'),
            SizedBox(height: 20,),
            Text(
              AppLocalizations.of(context).translate("contri"),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Senior Developer: John Doe'),
            Text('Git Software-production head : Jane Smith'),
            Text('App Developer: Alice Johnson'),
            Text('Designer: Bob Brown'),
          ],
        ),
      ),
    );
  }
}