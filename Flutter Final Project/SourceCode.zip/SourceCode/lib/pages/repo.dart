
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';



import 'create_repo.dart';
import 'localization.dart';

class RepositoryPage extends StatefulWidget {
  const RepositoryPage({Key? key}) : super(key: key);

  @override
  _RepositoryPageState createState() => _RepositoryPageState();
}

class _RepositoryPageState extends State<RepositoryPage> {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).translate("repository")),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Center(
          child: Column(
            children: [
              Row(
                children:[
                  SizedBox(width: 20.0,),
                  Text('Top ${AppLocalizations.of(context).translate('repository')}',style: TextStyle(fontSize: 20),),
                  SizedBox(width:100.0),
                    ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => CreateRepoPage()),
                      );
                    },
                    child: Text(AppLocalizations.of(context).translate('new'),style: TextStyle(color: Colors.white),),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                  ),
                ]
              ),
              Expanded(
                child: StreamBuilder(
                  stream: FirebaseFirestore.instance.collection('repositories').snapshots(),
                  builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(child: CircularProgressIndicator());
                    }

                    return ListView.builder(
                      itemCount: snapshot.data?.docs.length,
                      itemBuilder: (context, index) {
                        final DocumentSnapshot repository = snapshot.data!.docs[index];
                        return Card(
                          child:ListTile(
                          title: Text(repository['name']),
                          subtitle: Text(repository['language']),
                          trailing: Text(repository['access']),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      
    );
  }
}