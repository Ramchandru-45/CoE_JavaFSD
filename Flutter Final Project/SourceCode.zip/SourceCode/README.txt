1.The application starts from main.dart and calls the default localization 'en' and send this Locale to the homepage.dart.
2.homepage.dart contains the buttons for different pages that are essentially need for the application working.
3.ProfilePage.dart has user data that are logged in to the local storage.
4.credits.dart have the licencing and other details about app

5.repo.dart has the repositories to be listed and have a buuton "new" to add new repository.
6.The repo.dart requests the firebase connected to retrieve the repository from the firebase and add new repository to it.